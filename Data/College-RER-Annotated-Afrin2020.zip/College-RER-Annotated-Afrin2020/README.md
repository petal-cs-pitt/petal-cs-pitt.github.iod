Folder name indicates which group a student falls in according to the original study of college data 
[Zhang et. al.] A Corpus of Annotated Revisions for Studying Argumentative Writing, ACL 2017, https://aclanthology.org/P17-1144/

For revision desirability codes, look at this paper: https://aclanthology.org/2020.bea-1.7.pdf


FOLDER NAME DESCRIPTION
ESL-InterfaceA: ESL students using the ArgRewrite interface
ESL-InterfaceB: ESL students using the control interface
NATIVE-InterfaceA: NATIVE students using the ArgRewrite interface
NATIVE-InterfaceB: NATIVE students using the control interface


All files are from revision of Draft2 to Draft3.



EXCEL COLUMN NAMES:

Sentence Index - sentence index in the draft

Sentence Content - sentence text from the draft	

Aligned Index - aligned sentence index from new/old draft

Identical?	- if the sentence was not revised and identical in both drafts

Original Paragraph No - paragraph index of the sentence in old draft

New Paragraph No - paragraph index of the sentence in new draft

Revision Purpose Level 0 - revision purpose

Revision Operation Level 0	- revision operation

Revision Index Level 0 - revision index

Revision Desirability - RER codes



FILES:
EvidenceSentencePairData.xlsx - contains all extracted revisions for evidence revision
ReasoningSentencePairData.xlsx - contains all extracted revisions for reasoning revision
score.xlsx - score for each draft and each student